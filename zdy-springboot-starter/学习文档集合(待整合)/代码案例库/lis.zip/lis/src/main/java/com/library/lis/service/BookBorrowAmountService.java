package com.library.lis.service;


import com.library.lis.entity.BookBorrowAmount;

import java.util.Map;


public interface BookBorrowAmountService {


    Map<String, Object> pageList(BookBorrowAmount obj, String pageSize, String pageNo);

    BookBorrowAmount findById(Long id);

    void save(BookBorrowAmount obj);

    int exist(String month);

    void update(BookBorrowAmount obj);

    void deleteOne(long id);
}
