package com.library.lis.controller;

import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.BookRecommend;
import com.library.lis.entity.User;
import com.library.lis.entity.vo.BookRecommendVo;
import com.library.lis.service.BookRecommendService;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.Map;

@RestController
@RequestMapping("/bookRecommend")
public class BookRecommendController {

    @Autowired
    private Environment env;
    @Autowired
    private BookRecommendService bookRecommendService;

    @PostMapping("/save")
    public BaseResponse save(@RequestBody BookRecommend bookRecommend){
        User sessionUser = (User)SecurityUtils.getSubject().getPrincipal();

        try {
            if(0 == bookRecommend.getId()){
                bookRecommend.setCreateBy(sessionUser.getUserName());
                bookRecommendService.save(bookRecommend);
            }else{
                bookRecommend.setUpdateBy(sessionUser.getUserName());
                bookRecommend.setUpdateDate(new Date());
                bookRecommendService.update(bookRecommend);
            }
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }
        return new DataResponse("0","操作成功",bookRecommend);
    }

    @RequestMapping(value = "list")
    public DataResponse list(@RequestBody BookRecommendVo bookRecommendVo){

        Map<String, Object> result = bookRecommendService.pageList(bookRecommendVo);
        return new DataResponse("0","",result);

    }

    @PostMapping("/publishRecommend")
    public BaseResponse publishRecommend(@RequestParam(name = "dataId",required = false) Long dataId,
                                      @RequestParam(name = "isPublish") boolean isPublish){
        if(!StringUtils.isEmpty(dataId)){
            BookRecommend recommend = bookRecommendService.findById(dataId);
            if (isPublish) {
                recommend.setStatus(1);
            } else {
                recommend.setStatus(0);
            }
            bookRecommendService.update(recommend);
        }else {
            bookRecommendService.publishAllRecommend(isPublish?1:0);
        }
        return new BaseResponse("0","");
    }

}
