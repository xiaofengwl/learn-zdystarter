package com.library.lis.mapper;


import com.library.lis.entity.VisitsTimes;

import java.util.List;

public interface VisitsTimesMapper extends BaseMapper{

    int exist(String month);

    List<VisitsTimes> findByYear(String year);
}
