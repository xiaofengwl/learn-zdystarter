package com.library.lis.mapper;

public interface BookRecommendMapper extends BaseMapper{

    void publishAllRecommend(int status);
}
