package com.library.lis.service.impl;

import com.library.common.Pager;
import com.library.lis.entity.BookClassOffset;
import com.library.lis.entity.User;
import com.library.lis.mapper.BookClassOffsetMapper;
import com.library.lis.service.BookClassOffsetService;
import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class BookClassOffsetServiceImpl implements BookClassOffsetService {

    @Resource
    private BookClassOffsetMapper bookClassOffsetMapper;

    @Override
    public Map<String, Object> pageList(BookClassOffset obj, String pageSize, String pageNo) {
        Map<String, Object> map = new HashMap<>();

        Pager<BookClassOffset> pager = new Pager<>(Integer.parseInt(pageSize), Integer.parseInt(pageNo), obj);
        List list = bookClassOffsetMapper.pageList(pager);
        int count = bookClassOffsetMapper.count(pager);

        map.put("totalNum", count);
        map.put("list", list);
        map.put("pageSize", pageSize);
        map.put("pageNo", pageNo);
        return map;
    }



    @Override
    public BookClassOffset findById(Long id) {
        return (BookClassOffset) bookClassOffsetMapper.findById(id);
    }


    @Override
    public void save(BookClassOffset obj) {
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        if(bookClassOffsetMapper.exist(obj) > 0){
            obj.setUpdateBy(user.getUserName());
            obj.setUpdateDate(new Date());
            bookClassOffsetMapper.update(obj);
        }else{
            obj.setCreateDate(new Date());
            obj.setCreateBy(user.getUserName());
            bookClassOffsetMapper.save(obj);
        }

    }


    @Override
    public void update(BookClassOffset obj) {
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        obj.setUpdateBy(user.getUserName());
        obj.setUpdateDate(new Date());
        bookClassOffsetMapper.update(obj);
    }

    @Override
    public void deleteOne(long id) {
        bookClassOffsetMapper.delete(id);
    }


}
