package com.library.lis.mapper;

import com.library.common.Pager;

import java.util.List;


public interface BaseMapper<T> {

    List<T> pageList(Pager pager);

    int count(Pager pager);

    int save(Object obj);

    List<T> listAll();

    T findOne(T t);

    T findById(Long id);

    void update(Object obj);

    void delete(T t);

}
