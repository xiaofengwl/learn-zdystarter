package com.library.common;


import lombok.Data;

@Data
public class Pager<T> {

    private int start;
    private int pageSize;
    private T data;

    public Pager(int pageSize, int pageNo, T data){
        this.pageSize = pageSize;
        this.start = (pageNo -1) * pageSize;
        this.data = data;
    }
}
