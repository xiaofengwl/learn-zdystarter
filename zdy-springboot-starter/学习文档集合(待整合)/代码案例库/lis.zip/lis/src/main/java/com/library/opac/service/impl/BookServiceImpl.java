package com.library.opac.service.impl;

import com.library.anno.TargetDataSource;
import com.library.common.Pager;
import com.library.config.DataSourceEnum;
import com.library.lis.entity.BookRecommend;
import com.library.lis.entity.User;
import com.library.lis.mapper.BookLendMapper;
import com.library.opac.entity.Book;
import com.library.opac.entity.BookOrder;
import com.library.opac.entity.BookRank;
import com.library.opac.entity.LendWork;
import com.library.opac.mapper.BookMapper;
import com.library.opac.service.BookService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;


@Service
public class BookServiceImpl implements BookService {

    @Resource
    private BookMapper bookMapper;

    @Resource
    private BookLendMapper bookLendMapper;

    @TargetDataSource(DataSourceEnum.MySql)
    @Override
    public List<BookRecommend> getList(int pageNo, int pageSize, int status) {
        BookRecommend bookRecommend = new BookRecommend();
        bookRecommend.setStatus(1);
        Pager<BookRecommend> pager = new Pager<>(pageSize, pageNo, bookRecommend);
        return bookMapper.recommendBookList(pager);
    }


    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public List<BookRank> getTop10RankBook() {
        return bookLendMapper.getLendTop10Book();
    }


    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public Map<String, Object> getBookByClass(String type, int pageNo, int pageSize) {
        Book book = new Book();
        book.setBcid(type);
        Pager<Book> pager = new Pager<>(pageSize, pageNo, book);
        List<Book> books = bookMapper.pageList(pager);
        System.out.println(books);
        int count = bookMapper.count(pager);
        Map<String, Object> map = new HashMap<>();
        map.put("list", books);
        map.put("pageNo", pageNo);
        map.put("totalPage", (count + pageSize - 1) / pageSize);
        map.put("totalCnt", count);
        return map;
    }

    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public Book getBookById(String bid) {
        Book book=bookMapper.getBookById(bid);
        convertPjhFromBook(book);
        return book;
    }


    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public Map<String, Object> getBookByCondition(Book book, int pageNo, int pageSize) {
        Pager<Book> pager = new Pager<>(pageSize, pageNo, book);
        List<Book> books = bookMapper.searchPageList(pager);
        convertPjhFromBooks(books);
        System.out.println(books);
        int count = bookMapper.searchCount(pager);
        Map<String, Object> map = new HashMap<>();
        map.put("list", books);
        map.put("pageNo", pageNo);
        map.put("totalPage", (count + pageSize - 1) / pageSize);
        map.put("totalCnt", count);
        return map;
    }


    public void convertPjhFromBooks(List<Book> books) {
        try {
            Properties properties = new Properties();
            // 使用ClassLoader加载properties配置文件生成对应的输入流
            InputStream in = BookServiceImpl.class.getClassLoader().getResourceAsStream("region.properties");
            // 使用properties对象加载输入流
            BufferedReader bf = new BufferedReader(new InputStreamReader(in,"UTF-8"));
            properties.load(bf);
            //获取key对应的value值
            if (null != books && books.size() > 0) {
                for (Book book : books) {
                    String pjh = book.getPjh();
                    String region=properties.getProperty(pjh.substring(1, 2));
                    String convertedInfo =region+ pjh.substring(2, 5) + "架" + (pjh.substring(5, 6).equals("1") ? "A" : "B") + "面" + pjh.substring(6, 8) + "列" + "0" + pjh.substring(8, 9) + "层";
                    book.setPjh(convertedInfo);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void convertPjhFromBook(Book book) {

        try {
            Properties properties = new Properties();
            // 使用ClassLoader加载properties配置文件生成对应的输入流
            InputStream in = BookServiceImpl.class.getClassLoader().getResourceAsStream("region.properties");
            BufferedReader bf = new BufferedReader(new InputStreamReader(in,"UTF-8"));
            // 使用properties对象加载输入流
            properties.load(bf);
            if (null != book) {
                String pjh = book.getPjh();
                String region=properties.getProperty(pjh.substring(1, 2));
                String convertedInfo = region+pjh.substring(2, 5) + "架" + (pjh.substring(5, 6).equals("1") ? "A" : "B") + "面" + pjh.substring(6, 8) + "列" + "0" + pjh.substring(8, 9) + "层";
                book.setPjh(convertedInfo);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    @TargetDataSource(DataSourceEnum.SqlServer)
//    @Transactional
    public void bookOrder(Book book) {
        bookMapper.bookLendOut(book.getBid());

        BookOrder bookOrder = new BookOrder();
        bookOrder.setBcid(book.getBcid());
        bookOrder.setIsReader(0);
        bookOrder.setKind("图书");
        bookOrder.setPreeDate(new Date());

        User user = (User) SecurityUtils.getSubject().getPrincipal();
        String rid = user.getUserName();
        System.out.println(rid);
        bookOrder.setRid(rid);

        bookMapper.insertOrder(bookOrder);
    }

    @Override
    @TargetDataSource(DataSourceEnum.SqlServer)
    public List<LendWork> getLendingBook(String rid, int size) {
        return bookMapper.lendingBook(rid, size);
    }

    @Override
    @TargetDataSource(DataSourceEnum.SqlServer)
    public List<LendWork> lendHistory(String rid, int size) {
        return bookMapper.lendBookHistory(rid, size);
    }

    @Override
    @TargetDataSource(DataSourceEnum.SqlServer)
    public List<BookOrder> bookOrderHistory(String rid, int size) {
        return bookMapper.bookOrderHistory(rid, size);
    }


}
