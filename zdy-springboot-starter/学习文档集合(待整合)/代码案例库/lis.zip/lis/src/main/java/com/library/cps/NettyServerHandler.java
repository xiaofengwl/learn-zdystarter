package com.library.cps;


import com.library.lis.service.CpsDataService;
import com.library.utils.DateUtil;
import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;


@Slf4j
public class NettyServerHandler extends ChannelHandlerAdapter {



    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        log.info(">>>>>>>>>>>>>> Channel active");
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        log.info(">>>>>>>>>>>>>> 【收到消息】 ：" + msg.toString());
        Map<String, String> params = interpretingData(msg.toString());

        StringBuffer sb = new StringBuffer();
        if("2001".equals(params.get("Cmd"))){
            sb.append("#").append("Cmd=2001,").append("Time=" + DateUtil.currentTimeLong() + "$");
        }

        if("2002".equals(params.get("Cmd"))){
            SpringBeanFactory.getBean(CpsDataService.class).save(params);
            sb.append("#").append("Cmd=2002,").append("Seqid=" + params.get("Seqid") + "$");
        }
        log.info("【发送消息】: " + sb.toString());
        ctx.writeAndFlush(sb.toString());
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        ctx.close();
    }

    /**
     * 解析CPS客户端发送的数据
     * @param data
     * @return
     */
    private static Map<String, String> interpretingData(String data) {
        Map<String, String> params = new HashMap<>();
        if(data.startsWith("#")){
            data = data.substring(1);
        }
        if(data.contains("$")){
            data = data.split("\\$")[0];
        }
        String[] ary = data.split(",");
        for (String s: ary) {
            params.put(s.split("=")[0], s.split("=")[1]);
        }
        return params;
    }


}
