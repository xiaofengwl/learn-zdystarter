package com.library.lis.mapper;

import com.library.lis.entity.Notice;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface NoticeMapper {

    List<Notice> getList(@Param("offset") int offset,@Param("limit") int limit,@Param("status") int status);

    Integer getCount();

    void insertNotice(Notice notice);

    void saveNotice(Notice notice);

    void publishAllNotices(boolean isPublish);

    Notice findById(Integer noticeId);
}
