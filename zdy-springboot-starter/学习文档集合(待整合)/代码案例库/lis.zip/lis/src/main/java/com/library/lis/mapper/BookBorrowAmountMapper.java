package com.library.lis.mapper;


import com.library.lis.entity.BookBorrowAmount;

import java.util.List;

public interface BookBorrowAmountMapper extends BaseMapper{

    int exist(String month);

    List<BookBorrowAmount> findHalfYearMonthAmount(List<String> date);

}
