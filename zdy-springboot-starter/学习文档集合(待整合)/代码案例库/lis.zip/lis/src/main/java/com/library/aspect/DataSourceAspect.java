package com.library.aspect;


import com.library.anno.TargetDataSource;
import com.library.config.DataSourceContextHolder;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Component
@Aspect
public class DataSourceAspect {


    private static final Logger logger = LoggerFactory.getLogger(DataSourceAspect.class);

    @Pointcut("@annotation(com.library.anno.TargetDataSource)")
    public void dataSourcePointcut(){

    }

    @Before("dataSourcePointcut()")
    public void before(JoinPoint joinPoint){

        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();

        TargetDataSource annotation = method.getAnnotation(TargetDataSource.class);
        DataSourceContextHolder.setDataSource(annotation.value().getName());

        logger.info("【before】 " +joinPoint.getTarget().getClass() + " " + method.getName() + " " + annotation.value().getName());

    }

    @After("dataSourcePointcut()")
    public void after(JoinPoint joinPoint){
        DataSourceContextHolder.clear();
        logger.info("【after】 " +joinPoint.getTarget().getClass() + " "  + ((MethodSignature) joinPoint.getSignature()).getMethod().getName());

    }



}
