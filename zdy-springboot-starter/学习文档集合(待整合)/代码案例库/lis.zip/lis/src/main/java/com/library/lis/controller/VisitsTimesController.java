package com.library.lis.controller;

import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.BookBorrowAmount;
import com.library.lis.entity.VisitsTimes;
import com.library.lis.entity.vo.VisitsTimesVo;
import com.library.lis.service.VisitsTimesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;


@RestController
@RequestMapping("/VisitsTimes")
public class VisitsTimesController {

    private static final Logger logger = LoggerFactory.getLogger(VisitsTimesController.class);

    @Resource
    private VisitsTimesService visitsTimesService;


    @GetMapping("/pageList")
    public BaseResponse pageList(VisitsTimesVo vo, String pageSize, String pageNo){

        logger.info(">>>>>>>>>>> pageList <<<<<<<<<<<<<");

        if(StringUtils.isEmpty(pageSize)){
            return new BaseResponse("-1","【pageSize】不能传空");
        }
        if(StringUtils.isEmpty(pageNo)){
            return new BaseResponse("-1","【pageNo】不能传空");
        }

        VisitsTimes obj = new VisitsTimes();
        BeanUtils.copyProperties(vo, obj);

        Map<String, Object> map = visitsTimesService.pageList(obj, pageSize, pageNo);

        return new DataResponse<>("0", "", map);
    }


    @PostMapping("/add")
    public BaseResponse add(@RequestBody VisitsTimesVo vo){

        logger.info(">>>>>>>>>>> add <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(vo.getMonth())){
            return new BaseResponse("-1","【month】不能传空");
        }
        if(StringUtils.isEmpty(vo.getTimes())){
            return new BaseResponse("-1","【times】不能传空");
        }

        VisitsTimes obj = new VisitsTimes();
        BeanUtils.copyProperties(vo, obj);

        try{
            visitsTimesService.save(obj);
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }

        return new DataResponse<>("0", "", obj);
    }

    @PostMapping("/exist")
    public BaseResponse exist(@RequestBody VisitsTimesVo vo){

        logger.info(">>>>>>>>>>> exist <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(vo.getMonth())){
            return new BaseResponse("-1","【month】不能传空");
        }

        if(visitsTimesService.exist(vo.getMonth()) > 0){
            return new BaseResponse("-1","该月份已设置过");
        }else{
            return new BaseResponse("0", "可以使用");
        }
    }


    @GetMapping("/info/{id}")
    public BaseResponse info(@PathVariable String id){

        logger.info(">>>>>>>>>>> info <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(id)){
            return new BaseResponse("-1","【id】不能传空");
        }
        VisitsTimes obj = visitsTimesService.findById(Long.parseLong(id));
        return new DataResponse<>("0", "", obj);

    }


    @PostMapping("/update")
    public BaseResponse update(@RequestBody VisitsTimesVo vo){

        logger.info(">>>>>>>>>>> update <<<<<<<<<<<<<");

        if(StringUtils.isEmpty(vo.getId())){
            return new BaseResponse("-1","【id】不能传空");
        }
        if(StringUtils.isEmpty(vo.getMonth())){
            return new BaseResponse("-1","【month】不能传空");
        }
        if(StringUtils.isEmpty(vo.getTimes())){
            return new BaseResponse("-1","【times】不能传空");
        }

        VisitsTimes obj = new VisitsTimes();
        BeanUtils.copyProperties(vo, obj);
        try{
            visitsTimesService.update(obj);
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }
        return new BaseResponse("0","操作成功");
    }

    @DeleteMapping("/deleteOne/{id}")
    public BaseResponse deleteOne(@PathVariable String id){

        logger.info(">>>>>>>>>>> deleteOne <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(id)){
            return new BaseResponse("-1","【id】不能传空");
        }
        visitsTimesService.deleteOne(Long.parseLong(id));
        return new BaseResponse("0", "");

    }

}
