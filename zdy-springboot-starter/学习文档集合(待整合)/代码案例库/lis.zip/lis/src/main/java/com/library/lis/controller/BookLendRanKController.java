package com.library.lis.controller;

import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.BookLendRank;
import com.library.lis.entity.VisitsTimes;
import com.library.lis.entity.vo.BookLendRankVo;
import com.library.lis.entity.vo.VisitsTimesVo;
import com.library.lis.service.BookLendRankService;
import com.library.lis.service.VisitsTimesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;


@RestController
@RequestMapping("/BookLendRank")
public class BookLendRanKController {

    private static final Logger logger = LoggerFactory.getLogger(BookLendRanKController.class);

    @Resource
    private BookLendRankService bookLendRankService;


    @GetMapping("/pageList")
    public BaseResponse pageList(BookLendRankVo vo, String pageSize, String pageNo){

        logger.info(">>>>>>>>>>> pageList <<<<<<<<<<<<<");

        if(StringUtils.isEmpty(pageSize)){
            return new BaseResponse("-1","【pageSize】不能传空");
        }
        if(StringUtils.isEmpty(pageNo)){
            return new BaseResponse("-1","【pageNo】不能传空");
        }

        BookLendRank obj = new BookLendRank();
        BeanUtils.copyProperties(vo, obj);

        Map<String, Object> map = bookLendRankService.pageList(obj, pageSize, pageNo);

        return new DataResponse<>("0", "", map);
    }


    @PostMapping("/add")
    public BaseResponse add(@RequestBody BookLendRankVo vo){

        logger.info(">>>>>>>>>>> add <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(vo.getRank())){
            return new BaseResponse("-1","【rank】不能传空");
        }
        if(StringUtils.isEmpty(vo.getTimes())){
            return new BaseResponse("-1","【times】不能传空");
        }

        BookLendRank obj = new BookLendRank();
        BeanUtils.copyProperties(vo, obj);

        try{
            bookLendRankService.save(obj);
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }

        return new DataResponse<>("0", "", obj);
    }

    @PostMapping("/exist")
    public BaseResponse exist(@RequestBody BookLendRankVo vo){

        logger.info(">>>>>>>>>>> exist <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(vo.getRank())){
            return new BaseResponse("-1","【rank】不能传空");
        }

        if(bookLendRankService.exist(vo.getRank()) > 0){
            return new BaseResponse("-1","该排名已设置过");
        }else{
            return new BaseResponse("0", "可以使用");
        }
    }


    @GetMapping("/info/{id}")
    public BaseResponse info(@PathVariable String id){

        logger.info(">>>>>>>>>>> info <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(id)){
            return new BaseResponse("-1","【id】不能传空");
        }
        BookLendRank obj = bookLendRankService.findById(Long.parseLong(id));
        return new DataResponse<>("0", "", obj);

    }


    @PostMapping("/update")
    public BaseResponse update(@RequestBody BookLendRankVo vo){

        logger.info(">>>>>>>>>>> update <<<<<<<<<<<<<");

        if(StringUtils.isEmpty(vo.getId())){
            return new BaseResponse("-1","【id】不能传空");
        }
        if(StringUtils.isEmpty(vo.getRank())){
            return new BaseResponse("-1","【rank】不能传空");
        }
        if(StringUtils.isEmpty(vo.getTimes())){
            return new BaseResponse("-1","【times】不能传空");
        }

        BookLendRank obj = new BookLendRank();
        BeanUtils.copyProperties(vo, obj);
        try{
            bookLendRankService.update(obj);
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }
        return new BaseResponse("0","操作成功");
    }

    @DeleteMapping("/deleteOne/{id}")
    public BaseResponse deleteOne(@PathVariable String id){

        logger.info(">>>>>>>>>>> deleteOne <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(id)){
            return new BaseResponse("-1","【id】不能传空");
        }
        bookLendRankService.deleteOne(Long.parseLong(id));
        return new BaseResponse("0", "");

    }

}
