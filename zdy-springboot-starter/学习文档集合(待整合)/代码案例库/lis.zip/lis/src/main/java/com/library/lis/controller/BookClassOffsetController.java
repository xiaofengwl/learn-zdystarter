package com.library.lis.controller;

import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.BookClassOffset;
import com.library.lis.entity.vo.BookClassOffsetVo;
import com.library.lis.service.BookClassOffsetService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;


@RestController
@RequestMapping("/BookClassOffset")
public class BookClassOffsetController {

    private static final Logger logger = LoggerFactory.getLogger(BookClassOffsetController.class);

    @Resource
    private BookClassOffsetService bookClassOffsetService;


    @GetMapping("/pageList")
    public BaseResponse pageList(BookClassOffsetVo vo, String pageSize, String pageNo){

        logger.info(">>>>>>>>>>> pageList <<<<<<<<<<<<<");

        if(StringUtils.isEmpty(pageSize)){
            return new BaseResponse("-1","【pageSize】不能传空");
        }
        if(StringUtils.isEmpty(pageNo)){
            return new BaseResponse("-1","【pageNo】不能传空");
        }

        BookClassOffset obj = new BookClassOffset();
        BeanUtils.copyProperties(vo, obj);

        Map<String, Object> map = bookClassOffsetService.pageList(obj, pageSize, pageNo);

        return new DataResponse<>("0", "", map);
    }


    @PostMapping("/add")
    public BaseResponse add(@RequestBody BookClassOffsetVo vo){

        logger.info(">>>>>>>>>>> add <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(vo.getYear())){
            return new BaseResponse("-1","【year】不能传空");
        }
        if(StringUtils.isEmpty(vo.getOffset())){
            return new BaseResponse("-1","【offset】不能传空");
        }

        BookClassOffset obj = new BookClassOffset();
        BeanUtils.copyProperties(vo, obj);


        try{
            bookClassOffsetService.save(obj);
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }

        return new DataResponse<>("0", "", obj);
    }



    @PostMapping("/update")
    public BaseResponse update(@RequestBody BookClassOffsetVo vo){

        logger.info(">>>>>>>>>>> update <<<<<<<<<<<<<");

        if(StringUtils.isEmpty(vo.getId())){
            return new BaseResponse("-1","【id】不能传空");
        }
        if(StringUtils.isEmpty(vo.getYear())){
            return new BaseResponse("-1","【year】不能传空");
        }
        if(StringUtils.isEmpty(vo.getOffset())){
            return new BaseResponse("-1","【offset】不能传空");
        }

        BookClassOffset obj = new BookClassOffset();
        BeanUtils.copyProperties(vo, obj);
        try{
            bookClassOffsetService.update(obj);
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }
        return new BaseResponse("0","操作成功");
    }


    @DeleteMapping("/deleteOne/{id}")
    public BaseResponse deleteOne(@PathVariable String id){

        logger.info(">>>>>>>>>>> deleteOne <<<<<<<<<<<<<");
        if(StringUtils.isEmpty(id)){
            return new BaseResponse("-1","【id】不能传空");
        }
        bookClassOffsetService.deleteOne(Long.parseLong(id));
        return new BaseResponse("0", "");

    }

}
