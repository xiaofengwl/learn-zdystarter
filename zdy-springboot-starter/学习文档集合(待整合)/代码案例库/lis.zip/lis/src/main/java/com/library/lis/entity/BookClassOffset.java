package com.library.lis.entity;


import lombok.Data;

@Data
public class BookClassOffset extends BaseEntity{

    private String year; // 2019
    private String type; // 图书分类
    private String offset; // 修正值


}
