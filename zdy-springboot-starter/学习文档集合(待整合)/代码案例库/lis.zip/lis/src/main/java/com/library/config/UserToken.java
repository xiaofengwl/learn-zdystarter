package com.library.config;

import org.apache.shiro.authc.UsernamePasswordToken;

public class UserToken extends UsernamePasswordToken {

    private String loginType;


    public UserToken(String userName, final String password, String loginType){
        super(userName, password);
        this.loginType = loginType;
    }

    public String getLoginType(){
        return this.loginType;
    }

    public void setLoginType(String loginType){
        this.loginType = loginType;
    }


}
