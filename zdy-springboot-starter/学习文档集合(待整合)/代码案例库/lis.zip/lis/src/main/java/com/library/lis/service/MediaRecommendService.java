package com.library.lis.service;


import com.library.lis.entity.MediaRecommend;
import com.library.lis.entity.vo.MediaRecommendVo;

import java.util.List;
import java.util.Map;


public interface MediaRecommendService {


    Map<String, Object> pageList(MediaRecommendVo mediaRecommendVo);

    Map<String, Object> pageListOracle(MediaRecommendVo mediaRecommendVo);

    MediaRecommend findById(Long id);

    void save(MediaRecommend mediaRecommend);

    void update(MediaRecommend mediaRecommend);

    void publishAllRecommend(int status);

    List<String> findFileByMD5(String fileMD5);

}
