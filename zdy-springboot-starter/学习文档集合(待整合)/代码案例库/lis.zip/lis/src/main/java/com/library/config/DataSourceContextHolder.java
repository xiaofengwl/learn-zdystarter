package com.library.config;



public class DataSourceContextHolder {

    private static ThreadLocal<String> contextHolder = new InheritableThreadLocal<>();

    // 设置数据源名
    public static void setDataSource(String db){
        contextHolder.set(db);
    }

    //获取数据源名
    public static String getDataSource(){
        return contextHolder.get();
    }

    // 清除数据源名
    public static void clear(){
        contextHolder.remove();
    }

}
