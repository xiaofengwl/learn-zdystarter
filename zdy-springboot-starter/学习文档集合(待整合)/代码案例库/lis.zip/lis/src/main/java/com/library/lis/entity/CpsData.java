package com.library.lis.entity;


import lombok.Data;
import java.util.Date;

@Data
public class CpsData{

    private String cmd;
    private String code;
    private int getIn;
    private int getOut;
    private String time;
    private String seqId;
    private int year;
    private int month;
    private Date createTime;

}
