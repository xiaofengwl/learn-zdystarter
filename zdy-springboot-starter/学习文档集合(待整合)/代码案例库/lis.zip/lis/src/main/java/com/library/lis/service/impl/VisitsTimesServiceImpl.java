package com.library.lis.service.impl;

import com.library.common.Pager;
import com.library.lis.entity.User;
import com.library.lis.entity.VisitsTimes;
import com.library.lis.mapper.VisitsTimesMapper;
import com.library.lis.service.VisitsTimesService;
import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class VisitsTimesServiceImpl implements VisitsTimesService {

    @Resource
    private VisitsTimesMapper visitsTimesMapper;

    @Override
    public Map<String, Object> pageList(VisitsTimes obj, String pageSize, String pageNo) {
        Map<String, Object> map = new HashMap<>();

        Pager<VisitsTimes> pager = new Pager<>(Integer.parseInt(pageSize), Integer.parseInt(pageNo), obj);
        List list = visitsTimesMapper.pageList(pager);
        int count = visitsTimesMapper.count(pager);

        map.put("totalNum", count);
        map.put("list", list);
        map.put("pageSize", pageSize);
        map.put("pageNo", pageNo);
        return map;
    }

    @Override
    public VisitsTimes findById(Long id) {
        return (VisitsTimes) visitsTimesMapper.findById(id);
    }

    @Override
    public void save(VisitsTimes obj) {
        obj.setCreateDate(new Date());
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        obj.setCreateBy(user.getUserName());
        visitsTimesMapper.save(obj);
    }

    @Override
    public int exist(String month) {
        return visitsTimesMapper.exist(month);
    }

    @Override
    public void update(VisitsTimes obj) {
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        obj.setUpdateBy(user.getUserName());
        obj.setUpdateDate(new Date());
        visitsTimesMapper.update(obj);
    }

    @Override
    public void deleteOne(long id) {
        visitsTimesMapper.delete(id);
    }


}
