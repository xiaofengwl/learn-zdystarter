package com.library.lis.entity.vo;


import lombok.Data;

@Data
public class LoginVo {

    private String userName;
    private String password;
    private String verifyCode;
    private String loginType;


}
