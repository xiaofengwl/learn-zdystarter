package com.library.lis.entity;

import lombok.Data;

import java.util.Date;


@Data
public class Notice {//extends  BaseEntity{

    private Integer id;
    private String content;
    private Date createTime; // 创建时间
    private String createBy;
    private Date updateTime; // 修改时间
    private String updateBy;
    private Integer status; // 状态
}