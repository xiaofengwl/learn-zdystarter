package com.library.lis.entity;

import lombok.Data;

@Data
public class MediaRecommend extends BaseEntity {

    private int fileType;
    private String fileName;
    private String remark;
    private String filePath;
    private String fileMD5;
    private int status;

}
