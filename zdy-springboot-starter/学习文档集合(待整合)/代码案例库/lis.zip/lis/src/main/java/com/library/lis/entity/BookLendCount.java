package com.library.lis.entity;


import lombok.Data;

@Data
public class BookLendCount {

    private String bcid;
    private String title;
    private String cnt;


}
