package com.library.lis.mapper;


import com.library.lis.entity.BookClassOffset;

import java.util.List;

public interface BookClassOffsetMapper extends BaseMapper{

    int exist(BookClassOffset obj);

    List<BookClassOffset> findByYear(String year);

    List<BookClassOffset> findByYearList(String[] year);

}
