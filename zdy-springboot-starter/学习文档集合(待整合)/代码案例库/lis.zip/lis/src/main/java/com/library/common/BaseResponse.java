package com.library.common;


import lombok.Data;

import java.io.Serializable;

@Data
public class BaseResponse implements Serializable {

    private String code;
    private String msg;

    public BaseResponse(String code, String msg){
        this.code = code;
        this.msg = msg;
    }

}
