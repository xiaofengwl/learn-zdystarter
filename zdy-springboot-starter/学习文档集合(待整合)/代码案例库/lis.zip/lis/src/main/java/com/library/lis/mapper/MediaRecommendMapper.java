package com.library.lis.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MediaRecommendMapper extends BaseMapper{

    void publishAllRecommend(int status);

    List<String> findFileByMD5(String fileMD5);
}
