package com.library;

import com.library.cps.NettyServer;
import io.netty.channel.ChannelFuture;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import javax.annotation.Resource;

//禁用springboot默认单数据源配置
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
@MapperScan("com.library.*.mapper")
public class LisApplication {



    public static void main(String[] args) {
          SpringApplication.run(LisApplication.class, args);
    }

}
