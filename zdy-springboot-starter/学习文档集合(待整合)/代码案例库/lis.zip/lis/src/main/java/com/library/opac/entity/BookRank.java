package com.library.opac.entity;


import lombok.Data;

@Data
public class BookRank {

    private String title;
    private String isbn;
    private String bcid;
    private String writer;
    private String publish;
    private String cnt;

}
