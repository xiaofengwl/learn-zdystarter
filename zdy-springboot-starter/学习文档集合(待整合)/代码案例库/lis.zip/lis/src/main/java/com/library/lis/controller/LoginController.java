package com.library.lis.controller;


import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.config.LoginType;
import com.library.config.UserToken;
import com.library.constant.SystemConst;
import com.library.lis.entity.User;
import com.library.lis.service.UserService;
import com.library.utils.VerifyCodeUtil;
import com.library.lis.entity.vo.LoginVo;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.servlet.ShiroHttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@RestController
public class LoginController {


    @Resource
    private UserService userService;

    @PostMapping("/login")
    public BaseResponse login(@RequestBody LoginVo form){

        if(StringUtils.isEmpty(form.getUserName()) || StringUtils.isEmpty(form.getPassword())){
            return new BaseResponse("-1", "用户名或密码不能为空");
        }
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken usernamePasswordToken = new UserToken(form.getUserName(), form.getPassword(),
                form.getLoginType() == null? LoginType.Admin.name(): form.getLoginType());
        Session session = subject.getSession();

//        if(StringUtils.isEmpty(form.getVerifyCode()) || !form.getVerifyCode().equalsIgnoreCase((String) session.getAttribute("verifyCode"))){
//            return new BaseResponse("-1", "验证码错误");
//        }
        Map<String, String> reMap = new HashMap<>();
        try {
            subject.login(usernamePasswordToken);
        }catch (UnknownAccountException | IncorrectCredentialsException e){
            e.printStackTrace();
            return new BaseResponse("-1", "用户名或密码错误");
        } catch (AuthenticationException e) {
            e.printStackTrace();
            return new BaseResponse("-1", "认证失败");
        }
        reMap.put("token", session.getId().toString());
        reMap.put("name", form.getUserName());
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        reMap.put("avatar", user.getName());
        return new DataResponse<>("0", "操作成功", reMap);
    }



    @GetMapping("/logout")
    public BaseResponse logout(HttpServletRequest request){

        request.removeAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID);
        request.removeAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_IS_VALID);
        return new BaseResponse("0","操作成功");

    }


    @RequestMapping("unauth")
    public BaseResponse unauth(){
        return new BaseResponse(SystemConst.CODE_TOKEN_ILLEGAL, SystemConst.MSG_TOKEN_ILLEGAL);
    }


    @PostMapping("/modifyPwd")
    public BaseResponse modifyPwd(@RequestBody Map<String, String> map) throws IOException {

        String pwd1 = map.get("pwd1");
        String pwd2 = map.get("pwd2");
        String userName = map.get("userName");

        if(userName == null || "".equals(userName)){
            return new BaseResponse("-1", "用户名不能为空");
        }
        if(pwd1 == null || "".equals(pwd1) || pwd2 == null || "".equals(pwd2)){
            return new BaseResponse("-1", "密码不能为空");
        }
        if(!pwd1.equals(pwd2)){
            return new BaseResponse("-1", "密码不一致");
        }
        try {
            userService.modifyPwd(userName, pwd1);
            return new BaseResponse("0", "修改密码成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new BaseResponse("-1", "修改密码失败");
        }
    }


    @GetMapping("/verifyCode")
    public void verifyCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setHeader("Expires", "-1");
        response.setHeader("Cache-Control", "no-cache");
        response.setHeader("Pragma", "-1");
        response.setContentType("image/jpeg");

        String randomCode = VerifyCodeUtil.getRandomCode();
        request.getSession().setAttribute("verifyCode", randomCode);
        ImageIO.write(VerifyCodeUtil.genCaptcha(randomCode), "jpg", response.getOutputStream());

    }


}
