package com.library.lis.service;


import com.library.lis.entity.VisitsTimes;

import java.util.Map;


public interface VisitsTimesService {


    Map<String, Object> pageList(VisitsTimes obj, String pageSize, String pageNo);

    VisitsTimes findById(Long id);

    void save(VisitsTimes obj);

    int exist(String month);

    void update(VisitsTimes obj);

    void deleteOne(long id);
}
