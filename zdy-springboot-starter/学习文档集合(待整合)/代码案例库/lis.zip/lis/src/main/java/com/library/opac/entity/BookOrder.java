package com.library.opac.entity;


import lombok.Data;

import java.util.Date;

@Data
public class BookOrder {

    private String title;
    private String bcid;
    private String bid;
    private String writer;
    private Date preeDate;
    private int isReader;
    private String kind;
    private String rid;

}
