package com.library.lis.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


@Data
public abstract class BaseEntity implements Serializable {

    private long id;
    private String createBy;
    private Date createDate;
    private String updateBy;
    private Date updateDate;


}
