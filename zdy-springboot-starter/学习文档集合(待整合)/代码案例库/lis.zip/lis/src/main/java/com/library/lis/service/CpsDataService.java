package com.library.lis.service;


import com.library.lis.entity.CpsData;

import java.util.List;
import java.util.Map;


public interface CpsDataService {


    void save(Map<String, String> data);

    List<CpsData> listMonthVisits();

    void setGetInOffset(int[] month, int[] cnt);

    void getMonthCnt(List<CpsData> cpsData, int[] month, int[] cnt);
}
