package com.library.opac.mapper;


import com.library.opac.entity.Reader;

public interface ReaderMapper {

    Reader findByRid(String rid);

}
