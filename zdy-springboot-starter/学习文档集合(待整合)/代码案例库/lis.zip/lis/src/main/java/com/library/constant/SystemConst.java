package com.library.constant;

public class SystemConst {
	
	public static final String CODE_SUCCESS = "0";
	public static final String MSG_SUCCESS = "操作成功";

	public static final String CODE_FAIL = "-1";
	public static final String MSG_FAIL = "操作失败";
	public static final String SYS_MSG_FAIL = "系统异常";

	public static final String CODE_TOKEN_EXPIRED = "50000";
	public static final String MSG_TOKEN_EXPIRED  = "会话超时";

	public static final String CODE_TOKEN_ILLEGAL = "50001";
	public static final String MSG_TOKEN_ILLEGAL  = "无效的会话";

    public static final String TOKEN_OTHER_CLIENT_LOGGED = "50002";

	public static final String PASSWORD = "888888";

}
