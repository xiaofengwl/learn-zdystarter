package com.library.lis.service.impl;

import com.library.anno.TargetDataSource;
import com.library.common.Pager;
import com.library.config.DataSourceEnum;
import com.library.lis.entity.MediaRecommend;
import com.library.lis.entity.vo.MediaRecommendVo;
import com.library.lis.mapper.MediaRecommendMapper;
import com.library.lis.service.MediaRecommendService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class MediaRecommendServiceImpl implements MediaRecommendService {

    @Resource
    private MediaRecommendMapper mediaRecommendMapper;


    @Override
    @TargetDataSource()
    public Map<String, Object> pageList(MediaRecommendVo mediaRecommendVo){
        Map<String, Object> map = new HashMap<>();

        Pager<MediaRecommend> pager = new Pager<>(mediaRecommendVo.getPageSize(), mediaRecommendVo.getPageNo(), mediaRecommendVo);
        List list = mediaRecommendMapper.pageList(pager);
        int count = mediaRecommendMapper.count(pager);

        map.put("total", count);
        map.put("list", list);
        map.put("pageSize", mediaRecommendVo.getPageSize());
        map.put("pageNo", mediaRecommendVo.getPageNo());
        return map;
    }

    @Override
    @TargetDataSource(DataSourceEnum.Oracle)
    public Map<String, Object> pageListOracle(MediaRecommendVo mediaRecommendVo){
        Map<String, Object> map = new HashMap<>();

        Pager<MediaRecommend> pager = new Pager<>(mediaRecommendVo.getPageSize(), mediaRecommendVo.getPageNo(), mediaRecommendVo);
        List list = mediaRecommendMapper.pageList(pager);
        int count = mediaRecommendMapper.count(pager);

        map.put("total", count);
        map.put("list", list);
        map.put("pageSize", mediaRecommendVo.getPageSize());
        map.put("pageNo", mediaRecommendVo.getPageNo());
        return map;
    }

    @Override
    public MediaRecommend findById(Long id) {
        return (MediaRecommend) mediaRecommendMapper.findById(id);
    }

    @Override
    public void save(MediaRecommend mediaRecommend) {
        mediaRecommendMapper.save(mediaRecommend);
    }

    @Override
    public void update(MediaRecommend mediaRecommend) {
        mediaRecommendMapper.update(mediaRecommend);
    }

    @Override
    public void publishAllRecommend(int status) {
        mediaRecommendMapper.publishAllRecommend(status);
    }

    @Override
    public List<String> findFileByMD5(String fileMD5) {
        return mediaRecommendMapper.findFileByMD5(fileMD5);
    }

}
