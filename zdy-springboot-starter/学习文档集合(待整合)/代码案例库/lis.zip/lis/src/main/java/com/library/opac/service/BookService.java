package com.library.opac.service;


import com.library.lis.entity.BookRecommend;
import com.library.lis.entity.vo.BookRecommendVo;
import com.library.opac.entity.Book;
import com.library.opac.entity.BookOrder;
import com.library.opac.entity.BookRank;
import com.library.opac.entity.LendWork;

import java.util.List;
import java.util.Map;


public interface BookService {


    List<BookRecommend> getList(int pageNo, int pageSize, int status);

    List<BookRank> getTop10RankBook();

    Map<String, Object> getBookByClass(String type, int pageNo, int pageSize);

    Book getBookById(String bid);

    Map<String, Object> getBookByCondition(Book book, int pageNo, int pageSize);

    void bookOrder(Book book);

    List<LendWork> getLendingBook(String rid, int size);

    List<LendWork> lendHistory(String rid, int size);

    List<BookOrder> bookOrderHistory(String rid, int size);

}
