package com.library.opac.service;


import com.library.opac.entity.Reader;

public interface ReaderService {

    Reader findByRid(String rid);

}
