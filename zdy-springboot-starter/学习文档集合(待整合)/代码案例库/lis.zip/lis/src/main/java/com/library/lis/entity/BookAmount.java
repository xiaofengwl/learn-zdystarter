package com.library.lis.entity;


import lombok.Data;

@Data
public class BookAmount{

    private String year;
    private String cnt;


}
