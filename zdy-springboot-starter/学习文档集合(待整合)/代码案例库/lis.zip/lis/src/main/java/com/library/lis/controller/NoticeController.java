package com.library.lis.controller;


import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.Notice;
import com.library.lis.service.NoticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/notice")
public class NoticeController {

    @Autowired
    private NoticeService noticeService;

    @GetMapping("/list")
    public DataResponse list(@RequestParam(name = "page") Integer page,
                             @RequestParam(name = "limit") Integer limit,
                             @RequestParam(name = "status",required = false,defaultValue = "-1") Integer status){

        List<Notice> noticeList = noticeService.getList(page,limit,status);
        Map<String,Object> result = new HashMap<>();
        result.put("items",noticeList);
        result.put("total",noticeService.getCount());
        return new DataResponse("0","",result);

    }

    @PostMapping("/saveNotice")
    public BaseResponse saveNotice(@RequestBody Notice notice){
        Notice noticeEntity = new Notice();
        if(!StringUtils.isEmpty(notice.getId())){
            noticeEntity = noticeService.findById(notice.getId());
            noticeEntity.setUpdateTime(null);
        }

        noticeEntity.setContent(notice.getContent());
        noticeEntity.setStatus(0);
        noticeService.saveNotice(noticeEntity);
        return new BaseResponse("0","");
    }

    @PostMapping("/publishNotice")
    public BaseResponse publishNotice(@RequestParam(name = "noticeId",required = false) Integer noticeId,
                                      @RequestParam(name = "isPublish") boolean isPublish){
        if(!StringUtils.isEmpty(noticeId)){
            Notice notice = noticeService.findById(noticeId);
            if (isPublish) {
                notice.setStatus(1);
                notice.setUpdateTime(new Date());
            } else {
                notice.setStatus(0);
                notice.setUpdateTime(null);
            }
            noticeService.saveNotice(notice);
        }else {
            noticeService.publishAllNotices(false);
        }
        return new BaseResponse("0","");
    }

}
