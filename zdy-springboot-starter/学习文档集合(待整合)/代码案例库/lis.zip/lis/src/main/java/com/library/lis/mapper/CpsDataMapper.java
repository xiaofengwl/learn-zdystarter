package com.library.lis.mapper;


import com.library.lis.entity.CpsData;

import java.util.List;

public interface CpsDataMapper extends BaseMapper{

    List<CpsData> listMonthVisits(int year);

}
