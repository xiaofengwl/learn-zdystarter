package com.library.config;


import org.apache.shiro.authc.pam.AtLeastOneSuccessfulStrategy;
import org.apache.shiro.authc.pam.ModularRealmAuthenticator;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.session.mgt.SessionManager;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


@Configuration
public class ShiroConfig {


    @Bean
    public AuthorizingRealm adminShiroRealm(){
        return new AdminShiroRealm();
    }

    @Bean
    public AuthorizingRealm readerShiroRealm(){
        return new ReaderShiroRealm();
    }


    @Bean
    public SessionManager sessionManager(){
        return new MySessionManager();
    }


    @Bean
    public ModularRealmAuthenticator modularRealmAuthenticator(){
        UserModularRealmAuthenticator userModularRealmAuthenticator = new UserModularRealmAuthenticator();
        userModularRealmAuthenticator.setAuthenticationStrategy(new AtLeastOneSuccessfulStrategy());
        return userModularRealmAuthenticator;
    }

    @Bean
    public SecurityManager securityManager(){
        DefaultWebSecurityManager defaultWebSecurityManager = new DefaultWebSecurityManager();
        defaultWebSecurityManager.setAuthenticator(modularRealmAuthenticator());

        List<Realm> list = new ArrayList<>();
        list.add(adminShiroRealm());
        list.add(readerShiroRealm());
        defaultWebSecurityManager.setRealms(list);

        defaultWebSecurityManager.setSessionManager(sessionManager());
        return defaultWebSecurityManager;
    }



    @Bean
    public ShiroFilterFactoryBean shiroFilterFactoryBean(SecurityManager securityManager){
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        shiroFilterFactoryBean.setSecurityManager(securityManager);

        HashMap<String, String> map = new HashMap<>();
        map.put("/login", "anon");
        map.put("/verifyCode", "anon");
        map.put("/unauth", "anon");
        map.put("/bigData/**", "anon");
        map.put("/opacOpenApi/**", "anon");
        //对所以用户认证
        map.put("/**", "authc");
        //配置shiro默认登录界面地址，前后端分离中登录界面跳转应由前端路由控制，后台仅返回json数据
        shiroFilterFactoryBean.setLoginUrl("/unauth");

        shiroFilterFactoryBean.setFilterChainDefinitionMap(map);
        return shiroFilterFactoryBean;
    }



}
