package com.library.lis.service.impl;


import com.library.lis.entity.User;
import com.library.lis.mapper.UserMapper;
import com.library.lis.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class UserServiceImpl implements UserService {


    @Resource
    private UserMapper userMapper;

    @Override
    public User findByUserName(String userName) {
        return userMapper.getByUserName(userName);
    }

    @Override
    public void modifyPwd(String userName, String password) {
        User user = new User();
        user.setUserName(userName);
        user.setPassword(password);
        userMapper.modifyPwd(user);
    }


}
