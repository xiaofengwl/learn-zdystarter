package com.library.lis.api;


import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.*;
import com.library.lis.entity.vo.MediaRecommendVo;
import com.library.lis.service.*;
import com.library.utils.DateUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/bigData")
public class BigDataApi {


    @Resource
    private NoticeService noticeService;

    @Resource
    private BookRecommendService bookRecommendService;

    @Resource
    private MediaRecommendService mediaRecommendService;

    @Resource
    private BookLendService bookLendService;

    @Resource
    private BookClassService bookClassService;

    @Resource
    private CpsDataService cpsDataService;


    @RequestMapping("/getNotice")
    public BaseResponse getNotice(String pageNo, String pageSize){

        List<Notice> list = noticeService.getList(Integer.parseInt(pageNo), Integer.parseInt(pageSize), 1);
        return new DataResponse<>("0", "", list);
    }


    @RequestMapping("/getBooks")
    public BaseResponse getBooks(String pageNo, String pageSize){

        List<BookRecommend> list = bookRecommendService.getList(Integer.parseInt(pageNo), Integer.parseInt(pageSize), 1);
        return new DataResponse<>("0", "", list);
    }

    @RequestMapping("/getPicMedia")
    public BaseResponse getPicMedia(){

        MediaRecommendVo mediaRecommendVo = new MediaRecommendVo();
        mediaRecommendVo.setFileType(1);
        mediaRecommendVo.setPageNo(1);
        mediaRecommendVo.setPageSize(1);
        mediaRecommendVo.setStatus(1);

        //查有没有发布的视频
        Map<String, Object> map = mediaRecommendService.pageList(mediaRecommendVo);
        if (map.get("list") != null && ((List<MediaRecommend>) map.get("list")).size() > 0){
            return new DataResponse<>("0", "", map);
        }

        //没有发布的视频 查发布的图片
        mediaRecommendVo.setFileType(0);
        mediaRecommendVo.setPageSize(5);
        map = mediaRecommendService.pageList(mediaRecommendVo);
        return new DataResponse<>("0", "", map);

    }

    @RequestMapping("/getMonthLendBack")
    public BaseResponse getMonthLendBack(){

        Map<String, String[]> reMap = new HashMap<>();
        List<String> halfYearMonth = DateUtil.getHalfYearMonth();

        String[] month = new String[halfYearMonth.size()];
        String[] lend = new String[halfYearMonth.size()];
        String[] back = new String[halfYearMonth.size()];

        bookLendService.halfYearMonthLendBackStatistics(halfYearMonth, month, lend, back);

        bookLendService.setLendBackOffset(halfYearMonth, lend, back);

        reMap.put("month", month);
        reMap.put("lend", lend);
        reMap.put("back", back);

        return new DataResponse<>("0", "", reMap);

    }

    @RequestMapping("/getLendTop5Book")
    public BaseResponse getLendTop5Book(){
        List<BookLendCount> list = bookLendService.getTop5LendBook();
        bookLendService.setTop5Offset(list);
        return new DataResponse<>("0", "", list);

    }

    @RequestMapping("/getTop6BookClassCount")
    public BaseResponse getLendTop6BookClassCount(){
        List<BookClassCount> list = bookClassService.getTop6BookClassCount();
        bookClassService.setTop6Offset(list);
        return new DataResponse<>("0", "", list);

    }

    @RequestMapping("/getNearlyYearBookCount")
    public BaseResponse getNearlyYearBookCount(){

        Map<String, String[]> reMap = new HashMap<>();
        List<BookAmount> yearBookAmount = bookClassService.getYearBookAmount();

        if(yearBookAmount == null || yearBookAmount.size() == 0){
            return new BaseResponse("-1", "图书表无图书数据");

        }

        int localYear = LocalDate.now().getYear();
        //如果数据库中图书入库的最大年份小于当前年份，就把中间相差的年份图书数量初始化为 0
        if(Integer.parseInt(yearBookAmount.get(yearBookAmount.size()-1).getYear()) < localYear){
            for(int i = Integer.parseInt(yearBookAmount.get(yearBookAmount.size()-1).getYear()) + 1; i<= localYear; i++){
                BookAmount ba = new BookAmount();
                ba.setYear(String.valueOf(i));
                ba.setCnt("0");
                yearBookAmount.add(ba);
            }
        }

        if(yearBookAmount.size() == 1){
            BookAmount ba = new BookAmount();
            ba.setCnt(yearBookAmount.get(0).getCnt());
            ba.setYear(yearBookAmount.get(0).getYear());
            yearBookAmount.add(ba);
            yearBookAmount.get(0).setYear(String.valueOf(Integer.parseInt(yearBookAmount.get(0).getYear())-1));
            yearBookAmount.get(0).setCnt("0");
        }

        String[] year = new String[yearBookAmount.size()];
        String[] amount = new String[yearBookAmount.size()];

        for (int i=0; i<yearBookAmount.size(); i++){

            year[i] = yearBookAmount.get(i).getYear();
            amount[i] = yearBookAmount.get(i).getCnt();
        }

        reMap.put("year", year);
        reMap.put("amount", amount);

        bookClassService.setYearBookAmountOffset(yearBookAmount, reMap.get("year"), reMap.get("amount"));

        int total = 0;
        for(int i=0; i< reMap.get("amount").length; i++){
            if(i > 0){
                reMap.get("amount")[i] = String.valueOf(Integer.parseInt(reMap.get("amount")[i]) + Integer.parseInt(reMap.get("amount")[i-1]));
            }
            if((reMap.get("amount").length -1) == i){
                total = Integer.parseInt(reMap.get("amount")[i]);
            }
        }

        String[] totalAary = new String[1];
        totalAary[0] = String.valueOf(total);

        reMap.put("total", totalAary);
        return new DataResponse<>("0", "", reMap);
    }



    @RequestMapping("/getVisitsCnt")
    public BaseResponse getVisitsCnt(){
        Map<String, Object> map = new HashMap<>();

        int[] month = new int[12];
        int[] cnt = new int[12];

        List<CpsData> cpsData = cpsDataService.listMonthVisits();

        cpsDataService.getMonthCnt(cpsData, month, cnt);

        cpsDataService.setGetInOffset(month, cnt);

        int total = 0;
        for (int i = 0; i < cnt.length; i++) {
            total += cnt[i];
        }
        map.put("total", total);
        map.put("month", month);
        map.put("cnt", cnt);
        return new DataResponse<>("0", "", map);

    }

}
