package com.library.lis.service.impl;

import com.library.anno.TargetDataSource;
import com.library.config.DataSourceEnum;
import com.library.lis.entity.BookBorrowAmount;
import com.library.lis.entity.BookLend;
import com.library.lis.entity.BookLendCount;
import com.library.lis.entity.BookLendRank;
import com.library.lis.mapper.BookBorrowAmountMapper;
import com.library.lis.mapper.BookLendMapper;
import com.library.lis.mapper.BookLendRankMapper;
import com.library.lis.service.BookLendService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;


@Service
public class BookLendServiceImpl implements BookLendService {

    @Resource
    private BookLendMapper bookLendMapper;

    @Resource
    private BookBorrowAmountMapper bookBorrowAmountMapper;

    @Resource
    private BookLendRankMapper bookLendRankMapper;


    /**
     * 查询月度借还
     * @return
     */
    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public void halfYearMonthLendBackStatistics(List<String> halfYearMonth, String[] month, String[] lend, String[] back) {

        List<BookLend> halfYearMonthLend = bookLendMapper.getHalfYearMonthLend();
        List<BookLend> halfYearMonthBack = bookLendMapper.getHalfYearMonthBack();

        for(int i=0; i<halfYearMonth.size(); i++){

            month[i] = Integer.parseInt(halfYearMonth.get(i).split("-")[1]) + "月";

            for (BookLend bookLend : halfYearMonthLend) {
                if(Integer.parseInt(halfYearMonth.get(i).split("-")[1]) == Integer.parseInt(bookLend.getMonth())){
                    lend[i] = bookLend.getCnt();
                }else{
                    lend[i] = "0";
                }
            }

            for (BookLend bookBack : halfYearMonthBack) {
                if(Integer.parseInt(halfYearMonth.get(i).split("-")[1]) ==Integer.parseInt(bookBack.getMonth())){
                    back[i] = bookBack.getCnt();
                }else{
                    back[i] = "0";
                }
            }
        }

    }

    @TargetDataSource(DataSourceEnum.MySql)
    @Override
    public void setLendBackOffset(List<String> halfYearMonth, String[] lend, String[] back) {

        List<BookBorrowAmount> halfYearMonthAmount = bookBorrowAmountMapper.findHalfYearMonthAmount(halfYearMonth);
        if(halfYearMonthAmount == null || halfYearMonthAmount.size() == 0){
            return;
        }
        for (int i= 0; i<halfYearMonth.size(); i++){
            for(int j= 0; j<halfYearMonthAmount.size(); j++){
                if(halfYearMonth.get(i).equals(halfYearMonthAmount.get(j).getMonth())){
                    lend[i] = String.valueOf(Integer.parseInt(lend[i]) + Integer.parseInt(halfYearMonthAmount.get(j).getOutput()));
                    back[i] = String.valueOf(Integer.parseInt(back[i]) + Integer.parseInt(halfYearMonthAmount.get(j).getInput()));
                }
            }
        }

    }


    /**
     * 查询借阅前5名
     * @return
     */
    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public List<BookLendCount> getTop5LendBook() {
        return bookLendMapper.getLendTop5Book();
    }

    @TargetDataSource(DataSourceEnum.MySql)
    @Override
    public void setTop5Offset(List<BookLendCount> books) {
        List<BookLendRank> bookLendRankList = bookLendRankMapper.findAll();
        if (bookLendRankList == null || bookLendRankList.size() == 0){
            return;
        }
        for (BookLendRank rank: bookLendRankList){
            for (int i=0; i< books.size(); i++){
                if(Integer.parseInt(rank.getRank()) == (i + 1)){
                    books.get(i).setCnt(String.valueOf(Integer.parseInt(books.get(i).getCnt()) + Integer.parseInt(rank.getTimes())));
                }
            }
        }

        Collections.sort(books, (BookLendCount b1, BookLendCount b2) -> Integer.parseInt(b2.getCnt()) - Integer.parseInt(b1.getCnt()));
    }



}
