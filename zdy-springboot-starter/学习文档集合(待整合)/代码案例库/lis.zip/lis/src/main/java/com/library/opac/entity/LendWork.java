package com.library.opac.entity;


import lombok.Data;

import java.util.Date;

@Data
public class LendWork {

    private String title;
    private String bcid;
    private String bid;
    private String writer;
    private Date lendDate;
    private Date returnDate;
    private Date backDate;

}
