package com.library.lis.entity;

import lombok.Data;

@Data
public class BookRecommend extends BaseEntity {

    private String bookName;
    private String picName;
    private String picPath;
    private String fileMD5;
    private int status;

}
