package com.library.lis.service;


import com.library.lis.entity.User;


public interface UserService {

    User findByUserName(String userName);

    void modifyPwd(String userName, String pwd);

}
