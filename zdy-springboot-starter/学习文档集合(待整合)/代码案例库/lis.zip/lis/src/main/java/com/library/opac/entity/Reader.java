package com.library.opac.entity;


import lombok.Data;

@Data
public class Reader {

    private String name;

    private String rid;

    private String depId;

    private String picture;

    private String isFine;

    private String isGs;

    private String isFinish;

    private String rgid;

    private String guestPassword;

    private String isDisp;


}
