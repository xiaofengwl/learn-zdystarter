package com.library.lis.entity.vo;


import com.library.lis.entity.BaseEntity;
import lombok.Data;

@Data
public class VisitsTimesVo extends BaseEntity{

    private String month; //2019-11
    private String times; // 访问次数修正值


}
