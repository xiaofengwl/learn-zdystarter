package com.library.opac.api;


import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.BookRecommend;
import com.library.opac.entity.Book;
import com.library.opac.entity.BookOrder;
import com.library.opac.entity.BookRank;
import com.library.opac.entity.LendWork;
import com.library.opac.service.BookService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/opacOpenApi")
public class OpacOpenApi {


    @Resource
    private BookService bookService;


    @RequestMapping("/getNewBooks")
    public BaseResponse getNewBooks(String pageNo, String pageSize){

        List<BookRecommend> list = bookService.getList(Integer.parseInt(pageNo), Integer.parseInt(pageSize), 1);
        return new DataResponse<>("0", "", list);
    }

    @RequestMapping("/getBooksRank")
    public BaseResponse getBooksRank(){
        List<BookRank> top10RankBook = bookService.getTop10RankBook();
        return new DataResponse<>("0", "", top10RankBook);
    }

    @RequestMapping("/getBooksByClass")
    public BaseResponse getBooksByClass(String bcid, String pageNo, String pageSize){
        Map<String, Object> result = bookService.getBookByClass(bcid, Integer.parseInt(pageNo), Integer.parseInt(pageSize));
        return new DataResponse<>("0", "", result);
    }

    @RequestMapping("/getBookById")
    public BaseResponse getBookById(String bid){
        Book book = bookService.getBookById(bid);
        return new DataResponse<>("0", "", book);
    }

    @RequestMapping("/searchBooks")
    public BaseResponse searchBooks(Book book, String pageNo, String pageSize){
        Map<String, Object> result = bookService.getBookByCondition(book, Integer.parseInt(pageNo), Integer.parseInt(pageSize));
        return new DataResponse<>("0", "", result);
    }

    @RequestMapping("/bookOrder")
    public BaseResponse bookOrder(Book book){
        Book b = bookService.getBookById(book.getBid());
        if("0".equals(b.getState())){
            return new BaseResponse("-1", "图书在馆， 请按索书号【" + book.getBcid() + "】取书");
        }
        try{
            bookService.bookOrder(book);
            return new BaseResponse("0", "");
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1", "");
        }

    }


    @RequestMapping("/getLendingBook")
    public BaseResponse getLendingBook(String rid, int size){
        List<LendWork> lendingBook = bookService.getLendingBook(rid, size);
        return new DataResponse<>("0", "", lendingBook);
    }

    @RequestMapping("/lendBookHistory")
    public BaseResponse lendBookHistory(String rid, int size){
        List<LendWork> lendingBook = bookService.lendHistory(rid, size);
        return new DataResponse<>("0", "", lendingBook);
    }

    @RequestMapping("/getBookOrder")
    public BaseResponse getBookOrder(String rid, int size){
        List<BookOrder> bookOrders = bookService.bookOrderHistory(rid, size);
        return new DataResponse<>("0", "", bookOrders);
    }

}
