package com.library.lis.mapper;


import com.library.lis.entity.BookLendRank;

import java.util.List;

public interface BookLendRankMapper extends BaseMapper{

    int exist(String rank);

    List<BookLendRank> findAll();

}
