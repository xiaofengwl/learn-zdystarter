package com.library.lis.service;

import com.library.lis.entity.BookLendCount;

import java.util.List;

public interface BookLendService {

    void halfYearMonthLendBackStatistics(List<String> halfYearMonth, String[] month,String[] lend,String[] back);

    void setLendBackOffset(List<String> halfYearMonth, String[] lend,String[] back);

    List<BookLendCount> getTop5LendBook();

    void setTop5Offset(List<BookLendCount> books);

}
