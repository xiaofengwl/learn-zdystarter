package com.library.lis.entity;


import lombok.Data;

@Data
public class VisitsTimes extends BaseEntity{

    private String month; //2019-11
    private String times; // 访问次数修正值


}
