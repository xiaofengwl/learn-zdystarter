package com.library.lis.entity;


import lombok.Data;

@Data
public class BookLend {

    private String year;
    private String month;
    private String cnt;

}
