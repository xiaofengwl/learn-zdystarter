package com.library.lis.service.impl;

import com.library.common.Pager;
import com.library.lis.entity.BookRecommend;
import com.library.lis.entity.vo.BookRecommendVo;
import com.library.lis.mapper.BookRecommendMapper;
import com.library.lis.service.BookRecommendService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class BookRecommendServiceImpl implements BookRecommendService {

    @Resource
    private BookRecommendMapper bookRecommendMapper;


    @Override
    public Map<String, Object> pageList(BookRecommendVo bookRecommendVo){
        Map<String, Object> map = new HashMap<>();

        Pager<BookRecommend> pager = new Pager<>(bookRecommendVo.getPageSize(), bookRecommendVo.getPageNo(), bookRecommendVo);
        List list = bookRecommendMapper.pageList(pager);
        int count = bookRecommendMapper.count(pager);

        map.put("total", count);
        map.put("list", list);
        map.put("pageSize", bookRecommendVo.getPageSize());
        map.put("pageNo", bookRecommendVo.getPageNo());
        return map;
    }

    @Override
    public BookRecommend findById(Long id) {
        return (BookRecommend) bookRecommendMapper.findById(id);
    }

    @Override
    public void save(BookRecommend bookRecommend) {
        bookRecommendMapper.save(bookRecommend);
    }

    @Override
    public void update(BookRecommend bookRecommend) {
        bookRecommendMapper.update(bookRecommend);
    }

    @Override
    public void publishAllRecommend(int status) {
        bookRecommendMapper.publishAllRecommend(status);
    }

    @Override
    public List<BookRecommend> getList(int pageNo, int pageSize, int status) {
        BookRecommend bookRecommend = new BookRecommend();
        bookRecommend.setStatus(1);
        Pager<BookRecommend> pager = new Pager<>(pageSize, pageNo, bookRecommend);
        return bookRecommendMapper.pageList(pager);
    }


}
