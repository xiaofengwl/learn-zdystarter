package com.library.opac.entity;


import lombok.Data;

@Data
public class Book {

    private String title;
    private String isbn;
    private String bid;
    private String bcid;
    private String state;
    private String writer;
    private String publish;
    private String publishDate;
    private String pjh;
    private String skName;

}
