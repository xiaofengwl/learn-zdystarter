package com.library.lis.entity.vo;


import com.library.lis.entity.BaseEntity;
import lombok.Data;

@Data
public class BookClassOffsetVo extends BaseEntity{

    private String year; // 2019
    private String type; // 图书分类
    private String offset; // 修正值


}
