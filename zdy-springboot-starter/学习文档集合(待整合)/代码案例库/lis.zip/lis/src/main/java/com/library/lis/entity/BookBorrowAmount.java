package com.library.lis.entity;


import lombok.Data;

@Data
public class BookBorrowAmount extends BaseEntity{

    private String month; //2019-11
    private String output; // 借修正值
    private String input; // 还修正值


}
