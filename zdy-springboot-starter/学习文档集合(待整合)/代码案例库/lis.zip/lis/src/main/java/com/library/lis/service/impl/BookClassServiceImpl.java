package com.library.lis.service.impl;

import com.library.anno.TargetDataSource;
import com.library.config.DataSourceEnum;
import com.library.lis.entity.BookAmount;
import com.library.lis.entity.BookClassCount;
import com.library.lis.entity.BookClassOffset;
import com.library.lis.mapper.BookClassMapper;
import com.library.lis.mapper.BookClassOffsetMapper;
import com.library.lis.service.BookClassService;
import com.library.utils.DateUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Service
public class BookClassServiceImpl implements BookClassService {


    @Resource
    private BookClassMapper bookClassMapper;

    @Resource
    private BookClassOffsetMapper bookClassOffsetMapper;


    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public List<BookClassCount> getTop6BookClassCount() {

        return bookClassMapper.getTop6BookClassCount();

    }

    @TargetDataSource(DataSourceEnum.MySql)
    @Override
    public void setTop6Offset(List<BookClassCount> bookClassCountList) {
        int year = DateUtil.getCurrentYear();
        List<BookClassOffset> bookYearAmountList = bookClassOffsetMapper.findByYear(String.valueOf(year));

        for (BookClassCount count: bookClassCountList){
            for (BookClassOffset offset: bookYearAmountList) {
                if(count.getType().equals(offset.getType())){
                    count.setCnt(String.valueOf(Integer.parseInt(count.getCnt()) + Integer.parseInt(offset.getOffset())));
                }

            }
        }

    }


    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public List<BookAmount> getYearBookAmount() {
        return bookClassMapper.getBookYearAmount();
    }


    @TargetDataSource(DataSourceEnum.MySql)
    @Override
    public void setYearBookAmountOffset(List<BookAmount> list, String[] year, String[] amount) {
        if(list == null || list.size() == 0) return;
        List<BookClassOffset> offsetList = bookClassOffsetMapper.findByYearList(year);

        for(int i= 0; i< year.length; i++){
            for (int j=0; j< offsetList.size(); j ++){
                if(year[i].equals(offsetList.get(j).getYear())){
                    amount[i] = String.valueOf(Integer.parseInt(amount[i]) + Integer.parseInt(offsetList.get(j).getOffset()));
                }
            }
        }




    }


}
