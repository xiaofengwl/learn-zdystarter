package com.library.lis.service;


import com.library.lis.entity.BookLendRank;

import java.util.Map;


public interface BookLendRankService {


    Map<String, Object> pageList(BookLendRank obj, String pageSize, String pageNo);

    BookLendRank findById(Long id);

    void save(BookLendRank obj);

    int exist(String rank);

    void update(BookLendRank obj);

    void deleteOne(long id);

}
