package com.library.lis.entity.vo;

import com.library.lis.entity.BookRecommend;
import lombok.Data;

@Data
public class BookRecommendVo extends BookRecommend {

    private int pageSize;
    private int pageNo;

}
