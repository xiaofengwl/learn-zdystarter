package com.library.lis.service.impl;

import com.library.lis.entity.CpsData;
import com.library.lis.entity.VisitsTimes;
import com.library.lis.mapper.CpsDataMapper;
import com.library.lis.mapper.VisitsTimesMapper;
import com.library.lis.service.CpsDataService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Map;


@Service
public class CpsDataServiceImpl implements CpsDataService {

    @Resource
    private CpsDataMapper cpsDataMapper;

    @Resource
    private VisitsTimesMapper visitsTimesMapper;

    @Override
    public void save(Map<String, String> data) {
        CpsData cpsData = new CpsData();
        cpsData.setCmd(data.get("Cmd"));
        cpsData.setCode(data.get("Code"));
        cpsData.setGetIn(Integer.parseInt(data.get("GetIn")));
        cpsData.setGetOut(Integer.parseInt(data.get("GetOut")));
        cpsData.setTime(data.get("Time"));
        cpsData.setSeqId(data.get("Seqid"));

        Date date = new Date();
        cpsData.setCreateTime(date);
        cpsData.setMonth(LocalDate.now().getMonthValue());
        cpsData.setYear(LocalDate.now().getYear());

        cpsDataMapper.save(cpsData);
    }

    @Override
    public List<CpsData> listMonthVisits() {
        int year = LocalDate.now().getYear();
        return cpsDataMapper.listMonthVisits(year);
    }

    @Override
    public void setGetInOffset(int[] month, int[] cnt) {
        int year = LocalDate.now().getYear();
        List<VisitsTimes> monthOffsets= visitsTimesMapper.findByYear(year + "%");
        for (int i = 0; i <month.length; i++) {
            for (VisitsTimes times: monthOffsets) {
                if(Integer.parseInt(times.getMonth().split("-")[1]) == month[i]){
                    cnt[i] = cnt[i] + Integer.parseInt(times.getTimes());
                }
            }
        }
    }

    @Override
    public void getMonthCnt(List<CpsData> cpsDatas, int[] month, int[] cnt) {
        for (int i = 0; i <month.length; i++) {
            month[i] = i + 1;
            for (CpsData  cpsData: cpsDatas) {
                if(cpsData.getMonth() == month[i]){
                    cnt[i] = cpsData.getGetIn();
                }
            }
        }
    }


}
