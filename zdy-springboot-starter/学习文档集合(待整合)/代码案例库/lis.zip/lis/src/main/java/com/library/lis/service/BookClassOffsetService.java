package com.library.lis.service;


import com.library.lis.entity.BookClassOffset;

import java.util.Map;


public interface BookClassOffsetService {


    Map<String, Object> pageList(BookClassOffset obj, String pageSize, String pageNo);

    BookClassOffset findById(Long id);

    void save(BookClassOffset obj);

    void update(BookClassOffset obj);

    void deleteOne(long id);
}
