package com.library.lis.entity;

import lombok.Data;


@Data
public class User extends  BaseEntity{

    private String userName;
    private String name;
    private String password;
    private String sex;
    private String phone;
    private String idCard;
    private String delFlag;

    public static void main(String[] args) {
        String i="";
        if(i.equalsIgnoreCase("")){
            System.out.println(123);
        }
    }

}
