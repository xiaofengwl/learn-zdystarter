package com.library.lis.entity.vo;


import com.library.lis.entity.BaseEntity;
import lombok.Data;

@Data
public class BookBorrowAmountVo extends BaseEntity{

    private String month; //2019-11
    private String output; // 借修正值
    private String input; // 还修正值


}
