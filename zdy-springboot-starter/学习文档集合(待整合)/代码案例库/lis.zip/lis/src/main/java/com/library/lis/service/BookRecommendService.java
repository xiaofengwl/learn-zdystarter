package com.library.lis.service;


import com.library.lis.entity.BookRecommend;
import com.library.lis.entity.vo.BookRecommendVo;

import java.util.List;
import java.util.Map;


public interface BookRecommendService {


    Map<String, Object> pageList(BookRecommendVo bookRecommendVo);

    BookRecommend findById(Long id);

    void save(BookRecommend bookRecommend);

    void update(BookRecommend bookRecommend);

    void publishAllRecommend(int status);

    List<BookRecommend> getList(int pageNo, int pageSize, int status);


}
