package com.library.lis.mapper;


import com.library.lis.entity.User;


public interface UserMapper {

    User getByUserName(String userName);

    void modifyPwd(User user);

}
