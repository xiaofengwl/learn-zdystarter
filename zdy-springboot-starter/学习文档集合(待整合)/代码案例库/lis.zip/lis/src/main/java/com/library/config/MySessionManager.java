package com.library.config;

import org.apache.shiro.web.servlet.ShiroHttpServletRequest;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

public class MySessionManager extends DefaultWebSessionManager {

    private static final String X_TOKEN = "X-Token";

    private static final Logger log = LoggerFactory.getLogger(MySessionManager.class);

    public MySessionManager(){
        setGlobalSessionTimeout(MILLIS_PER_MINUTE * 30);
    }


    protected Serializable getSessionId(ServletRequest request, ServletResponse response){

        String token = WebUtils.toHttp(request).getHeader(X_TOKEN);
        String host = request.getRemoteHost();
        log.info(host + ((HttpServletRequest)request).getRequestURI() + " >>>>>> X-Token = "+token);

        if(!StringUtils.isEmpty(token)){
            request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID, token);
            request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_IS_VALID, Boolean.TRUE);
            return token;
        }else{
            return super.getSessionId(request, response);
        }


    }

}
