package com.library.lis.controller;

import com.library.common.BaseResponse;
import com.library.common.DataResponse;
import com.library.lis.entity.MediaRecommend;
import com.library.lis.entity.User;
import com.library.lis.entity.vo.MediaRecommendVo;
import com.library.lis.service.MediaRecommendService;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.Map;

@RestController
@RequestMapping("/mediaRecommend")
public class MediaRecommendController {

    @Autowired
    private MediaRecommendService mediaRecommendService;

    @PostMapping("/save")
    public BaseResponse save(@RequestBody MediaRecommend mediaRecommend){
        User sessionUser = (User)SecurityUtils.getSubject().getPrincipal();

        try {
            if(0 == mediaRecommend.getId()){
                mediaRecommend.setCreateBy(sessionUser.getUserName());
                mediaRecommendService.save(mediaRecommend);
            }else{
                mediaRecommend.setUpdateBy(sessionUser.getUserName());
                mediaRecommend.setUpdateDate(new Date());
                mediaRecommendService.update(mediaRecommend);
            }
        }catch (Exception e){
            e.printStackTrace();
            return new BaseResponse("-1","操作失败");
        }
        return new DataResponse("0","操作成功",mediaRecommend);
    }

    @RequestMapping(value = "list")
    public DataResponse list(@RequestBody MediaRecommendVo mediaRecommendVo){
        Map<String, Object> result = mediaRecommendService.pageList(mediaRecommendVo);
        return new DataResponse("0","",result);

    }

    @RequestMapping(value = "oraclelist")
    public DataResponse oraclelist(@RequestBody MediaRecommendVo mediaRecommendVo){
        Map<String, Object> result = mediaRecommendService.pageListOracle(mediaRecommendVo);
        return new DataResponse("0","",result);

    }

    @PostMapping("/publishRecommend")
    public BaseResponse publishRecommend(@RequestParam(name = "dataId",required = false) Long dataId,
                                      @RequestParam(name = "isPublish") boolean isPublish){
        if(!StringUtils.isEmpty(dataId)){
            MediaRecommend recommend = mediaRecommendService.findById(dataId);
            if (isPublish) {
                recommend.setStatus(1);
            } else {
                recommend.setStatus(0);
            }
            mediaRecommendService.update(recommend);
        }else {
            mediaRecommendService.publishAllRecommend(isPublish?1:0);
        }
        return new BaseResponse("0","");
    }

}
