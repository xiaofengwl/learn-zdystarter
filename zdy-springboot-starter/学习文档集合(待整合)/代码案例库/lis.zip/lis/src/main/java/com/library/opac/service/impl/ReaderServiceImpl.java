package com.library.opac.service.impl;


import com.library.anno.TargetDataSource;
import com.library.config.DataSourceEnum;
import com.library.opac.entity.Reader;
import com.library.opac.mapper.ReaderMapper;
import com.library.opac.service.ReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class ReaderServiceImpl implements ReaderService {

    @Resource
    private ReaderMapper readerMapper;

    @TargetDataSource(DataSourceEnum.SqlServer)
    @Override
    public Reader findByRid(String rid) {
        return readerMapper.findByRid(rid);
    }
}
