package com.library.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static java.util.Calendar.MONTH;

public class DateUtil {


    /**
     * 获取近6个月的月份  yyyy-MM
     * @return
     */
    public static ArrayList<String> getHalfYearMonth() {

        ArrayList<String> month = new ArrayList<>();
        Calendar c = Calendar.getInstance();
        c.add(MONTH, -4);
        String before_six = c.get(Calendar.YEAR) + "-" + c.get(MONTH);//5个月前
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");// 格式化为年月
        Calendar min = Calendar.getInstance();
        Calendar max = Calendar.getInstance();
        try {
            min.setTime(sdf.parse(before_six));
            min.set(min.get(Calendar.YEAR), min.get(MONTH), 1);
            max.setTime(sdf.parse(sdf.format(new Date())));
            max.set(max.get(Calendar.YEAR), max.get(MONTH), 2);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar curr = min;
        while (curr.before(max)) {
            month.add(sdf.format(curr.getTime()));
            curr.add(MONTH, 1);
        }
        System.out.println(month);
        return month;
    }


    /**
     * 获取当前年份 yyyy
     * @return
     */
    public static int getCurrentYear() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR);
    }


    /**
     * 获取最近的年份数组 yyyy
     * @param num
     * @return
     */

    public static ArrayList<String> getNearlyYear(int num) {

        ArrayList<String> list = new ArrayList<>();
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);

        for(int i = num-1 ; i>= 0; i --){
            list.add(String.valueOf(year-i));
        }
        System.out.println(list);
        return list;
    }

    /**
     * 获取当前秒级时间戳
     * @return
     */
    public static long currentTimeLong() {
        LocalDateTime now = LocalDateTime.now();
        return now.toEpochSecond(ZoneOffset.of("+8"));
    }

}
