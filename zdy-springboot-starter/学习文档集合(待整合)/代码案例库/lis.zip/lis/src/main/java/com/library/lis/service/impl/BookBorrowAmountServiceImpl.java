package com.library.lis.service.impl;

import com.library.common.Pager;
import com.library.lis.entity.BookBorrowAmount;
import com.library.lis.entity.User;
import com.library.lis.mapper.BookBorrowAmountMapper;
import com.library.lis.service.BookBorrowAmountService;
import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



@Service
public class BookBorrowAmountServiceImpl implements BookBorrowAmountService {

    @Resource
    private BookBorrowAmountMapper bookBorrowAmountMapper;

    @Override
    public Map<String, Object> pageList(BookBorrowAmount obj, String pageSize, String pageNo) {
        Map<String, Object> map = new HashMap<>();

        Pager<BookBorrowAmount> pager = new Pager<>(Integer.parseInt(pageSize), Integer.parseInt(pageNo), obj);
        List list = bookBorrowAmountMapper.pageList(pager);
        int count = bookBorrowAmountMapper.count(pager);

        map.put("totalNum", count);
        map.put("list", list);
        map.put("pageSize", pageSize);
        map.put("pageNo", pageNo);
        return map;
    }

    @Override
    public BookBorrowAmount findById(Long id) {
        return (BookBorrowAmount) bookBorrowAmountMapper.findById(id);
    }

    @Override
    public void save(BookBorrowAmount obj) {
        obj.setCreateDate(new Date());
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        obj.setCreateBy(user.getUserName());
        bookBorrowAmountMapper.save(obj);
    }

    @Override
    public int exist(String month) {
        return bookBorrowAmountMapper.exist(month);
    }

    @Override
    public void update(BookBorrowAmount obj) {
        User user = (User) SecurityUtils.getSubject().getPrincipal();
        obj.setUpdateBy(user.getUserName());
        obj.setUpdateDate(new Date());
        bookBorrowAmountMapper.update(obj);
    }

    @Override
    public void deleteOne(long id) {
        bookBorrowAmountMapper.delete(id);
    }


}
