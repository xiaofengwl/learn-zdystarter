package com.library.lis.entity;


import lombok.Data;

@Data
public class BookLendRank extends BaseEntity{

    private String rank; //1,2,3,4,5
    private String times; // 访问次数修正值


}
