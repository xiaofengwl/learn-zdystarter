package com.library.common;


import lombok.Data;

@Data
public class DataResponse<T> extends BaseResponse{

    private T data;

    public DataResponse(String code, String msg, T data){
        super(code,msg);
        this.data = data;
    }

}
