package com.library.opac.mapper;

import com.library.common.Pager;
import com.library.lis.entity.BookRecommend;
import com.library.lis.mapper.BaseMapper;
import com.library.opac.entity.Book;
import com.library.opac.entity.BookOrder;
import com.library.opac.entity.LendWork;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BookMapper extends BaseMapper{

    List<BookRecommend> recommendBookList(Pager pager);

    List<Book> pageList(Pager pager);

    int count(Pager pager);

    Book getBookById(String bid);

    List<Book> searchPageList(Pager<Book> pager);

    int searchCount(Pager pager);

    void bookLendOut(String bid);

    void insertOrder(BookOrder order);

    List<LendWork> lendingBook(@Param("rid") String rid, @Param("size") int size);

    List<LendWork> lendBookHistory(@Param("rid")String rid, @Param("size") int size);

    List<BookOrder> bookOrderHistory(@Param("rid")String rid, @Param("size") int size);


}
