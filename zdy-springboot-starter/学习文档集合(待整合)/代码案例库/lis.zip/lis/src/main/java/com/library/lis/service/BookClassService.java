package com.library.lis.service;

import com.library.lis.entity.BookAmount;
import com.library.lis.entity.BookClassCount;

import java.util.List;
import java.util.Map;

public interface BookClassService {


    List<BookClassCount> getTop6BookClassCount();

    void setTop6Offset(List<BookClassCount> books);

    List<BookAmount> getYearBookAmount();

    void setYearBookAmountOffset(List<BookAmount> list, String[] years, String[] amounts);

}
