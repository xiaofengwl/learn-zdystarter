package com.library.config;

public enum  DataSourceEnum {

    MySql("mysqlDataSource"), SqlServer("sqlServerDataSource"), Oracle("oracleDataSource");

    private String name;

    DataSourceEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
