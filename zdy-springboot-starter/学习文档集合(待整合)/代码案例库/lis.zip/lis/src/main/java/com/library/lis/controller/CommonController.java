package com.library.lis.controller;

import com.library.common.DataResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/common")
public class CommonController{

    @Value("${uploadPath}")
    private String nginxHtml;

    // nginx根目录下的html下的upload文件夹名称
    private static final String TARGET_FILE_NAME = "upload";


    @RequestMapping("/upload")
    public DataResponse uploadOnePic(@RequestParam(name = "file")MultipartFile file){

        if (file == null) {
            return new DataResponse<>("-1","文件不能为空",null);
        }
        String originalFileName = file.getOriginalFilename();
        if (originalFileName == null || "".equals(originalFileName) || !originalFileName.contains(".")) {
            return new DataResponse<>("-1","文件格式不正确",null);
        }

        String fileMD5 = null;
        try {
            fileMD5 = DigestUtils.md5DigestAsHex(file.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
            return new DataResponse<>("-1","md5签名失败",null);
        }

        String fileName = originalFileName.split("\\.")[0];
        String suffix = originalFileName.split("\\.")[1];

        //检查是否上传过同名文件
        File uploadDir = new File(nginxHtml + TARGET_FILE_NAME + "/" + fileName);

        if(!uploadDir.exists()){
            uploadDir.mkdirs();
        }else{
            String uploadedFileName = null;
            try {
                uploadedFileName = isUploaded(uploadDir, fileMD5);
            } catch (IOException e) {
                e.printStackTrace();
                return new DataResponse<>("-1","md5校验失败",null);
            }
            if(uploadedFileName != null){
                Map<String,String> res = new HashMap<>();
                res.put("fileName",originalFileName);
                res.put("filePath",TARGET_FILE_NAME + "/" + fileName + "/" + uploadedFileName);
                res.put("fileMD5",fileMD5);
                return new DataResponse<>("0","上传成功",res);
            }
        }

        String newFileName =  new Date().getTime() + "." + suffix;
        String filePath = fileName + "/" + newFileName;
        try {
            file.transferTo(new File(nginxHtml + TARGET_FILE_NAME + "/" + fileName + "/" + newFileName));
            Map<String,String> res = new HashMap<>();
            res.put("fileName",originalFileName);
            res.put("filePath",TARGET_FILE_NAME + "/" + filePath);
            res.put("fileMD5",fileMD5);
            return new DataResponse<>("0","上传成功",res);
        } catch (IOException e) {
            e.printStackTrace();
            return new DataResponse<>("-1","上传失败",null);
        }

    }

    /**
     * 检查是否已上传过同名文件且MD%相同的文件
     * @param uploadDir
     * @param fileMD5
     * @return
     * @throws IOException
     */
    private String isUploaded(File uploadDir, String fileMD5) throws IOException {
        File[] sameNameFiles = uploadDir.listFiles();
        if(sameNameFiles == null || sameNameFiles.length ==0) {
            return null;
        }
        for (File f : sameNameFiles) {
            String existsFileMD5 = DigestUtils.md5DigestAsHex(new FileInputStream(f));
            if(fileMD5.equals(existsFileMD5)){
                return f.getName();
            }
        }
        return null;
    }


}
