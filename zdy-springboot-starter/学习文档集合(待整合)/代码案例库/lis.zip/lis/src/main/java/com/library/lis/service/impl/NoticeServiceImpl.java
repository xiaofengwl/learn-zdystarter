package com.library.lis.service.impl;


import com.library.lis.entity.Notice;
import com.library.lis.entity.User;
import com.library.lis.mapper.NoticeMapper;
import com.library.lis.service.NoticeService;
import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


@Service
public class NoticeServiceImpl implements NoticeService {


    @Resource
    private NoticeMapper noticeMapper;


    @Override
    public Integer getCount() {
        return noticeMapper.getCount();
    }

    @Override
    public List<Notice> getList(int pageNo,int pageSize, int status) {
        int offset = (pageNo - 1) * pageSize;
        int limit = pageSize;
        return noticeMapper.getList(offset,limit,status);
    }

    @Override
    public void saveNotice(Notice notice) {
        User sessionUser = (User)SecurityUtils.getSubject().getPrincipal();
        if(StringUtils.isEmpty(notice.getId())){
            notice.setCreateBy(sessionUser.getUserName());
            noticeMapper.insertNotice(notice);
        }else{
            notice.setUpdateBy(sessionUser.getUserName());
            noticeMapper.saveNotice(notice);
        }
    }

    @Override
    public Notice findById(Integer noticeId) {
        return noticeMapper.findById(noticeId);
    }

    @Override
    public void publishAllNotices(boolean isPublish) {
        noticeMapper.publishAllNotices(isPublish);
    }

}
