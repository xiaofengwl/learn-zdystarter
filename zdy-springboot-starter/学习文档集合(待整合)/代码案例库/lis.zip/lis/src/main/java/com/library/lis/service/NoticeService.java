package com.library.lis.service;

import com.library.lis.entity.Notice;

import java.util.List;

public interface NoticeService {

    Integer getCount();

    List<Notice> getList(int pageNo,int pageSize, int status);

    void saveNotice(Notice notice);

    void publishAllNotices(boolean isPublish);

    Notice findById(Integer noticeId);

}
