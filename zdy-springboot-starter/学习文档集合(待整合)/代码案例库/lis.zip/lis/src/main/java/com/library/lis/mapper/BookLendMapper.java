package com.library.lis.mapper;

import com.library.lis.entity.BookLend;
import com.library.lis.entity.BookLendCount;
import com.library.opac.entity.BookRank;

import java.util.List;

public interface BookLendMapper {

    List<BookLend> getHalfYearMonthLend();

    List<BookLend> getHalfYearMonthBack();

    List<BookLendCount> getLendTop5Book();

    List<BookRank> getLendTop10Book();

}
