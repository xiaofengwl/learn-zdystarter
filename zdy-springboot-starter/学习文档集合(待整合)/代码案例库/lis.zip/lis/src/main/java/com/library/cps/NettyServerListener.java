package com.library.cps;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.util.Calendar;
import java.util.concurrent.*;


@Slf4j
@WebListener
public class NettyServerListener implements ServletContextListener {


    private ExecutorService webSocketSinglePool;
    private NettyServer nettyServer;


    @PostConstruct
    public void setup(){
        ThreadFactory namedThreadFactory = new ThreadFactoryBuilder()
                .setNameFormat("webSocketSinglePool-%d").build();
        webSocketSinglePool = new ThreadPoolExecutor(1, 1, 0L,
                TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(1024),
                namedThreadFactory, new ThreadPoolExecutor.AbortPolicy());
        log.info("webSocketSinglePool init.");
    }

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        log.info("tomcat is going start");
        WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContextEvent.getServletContext());
        Environment environment = webApplicationContext.getEnvironment();
        String port = environment.getProperty("nettyServer.port");
        log.info("netty 配置端口：" + port);
        nettyServer = webApplicationContext.getBean(NettyServer.class);

        Thread t=Thread.currentThread();
        log.info("run() of netty"+ Calendar.getInstance().getTime()+"___"+t.getName()+"  flag:"+(null==nettyServer));

        webSocketSinglePool.execute(()->{
            try {
                log.info("running......");
                nettyServer.start(Integer.parseInt(port));
            } catch (Exception e) {
                log.error("NettyServerListener listen and serve error.", e);
            }
        });

    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        log.info("tomcat is deading");
        log.info("destroy() of netty"+ Calendar.getInstance().getTime()+"  flag:"+(null==nettyServer));
        new Thread(()->nettyServer.destroy()).run();
    }


    @PreDestroy
    public void  cleanup(){
        webSocketSinglePool.shutdown();
        log.info("webSocketSinglePool destroyed.");
    }
}
