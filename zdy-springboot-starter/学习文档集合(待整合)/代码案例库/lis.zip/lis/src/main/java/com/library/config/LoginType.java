package com.library.config;

public enum  LoginType {

    Reader("reader"), Admin("admin");

    private String type;

    LoginType(String type){
        this.type = type;
    }

}
