package com.library.lis.entity.vo;


import com.library.lis.entity.BaseEntity;
import lombok.Data;

@Data
public class BookLendRankVo extends BaseEntity{

    private String rank; //1,2,3,4,5
    private String times; // 借修正值


}
