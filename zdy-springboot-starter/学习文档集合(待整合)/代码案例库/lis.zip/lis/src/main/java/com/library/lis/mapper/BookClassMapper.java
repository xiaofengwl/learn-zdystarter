package com.library.lis.mapper;

import com.library.lis.entity.BookAmount;
import com.library.lis.entity.BookClassCount;

import java.util.List;

public interface BookClassMapper {


    List<BookClassCount> getTop6BookClassCount();

    List<BookAmount> getBookYearAmount();


}
