package com.library.lis.entity;


import lombok.Data;

@Data
public class BookClassCount {

    private String type;
    private String cnt;


}
